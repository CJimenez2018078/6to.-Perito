'use strict'

var mongoose = require('mongoose');
var app = require('./app');
var port = 3801;

mongoose.Promise = global.Promise;
mongoose.connect('mongodb://localhost:27017/Zoologico2018078', {useNewUrlParser: true, useUnifiedTopology: true})
    .then(()=>{
        console.log('Conexion a base de datos exitosa');
        app.listen(port, ()=>{
            console.log('Servidor express corriendo:', port);
        });
    })
    .catch(err=>{
        console.log('Error conexion a base de datos', err);
    });