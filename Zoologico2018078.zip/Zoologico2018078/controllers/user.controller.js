'use strict'
var User = require('../models/user.model');
//Login
function login(req, res){
    let params= req.body;
    if(params.username && params.password){
        User.findOne({username: params.username, password:params.password}, (err, user)=>{
            if(err){
                res.status(500).send({message: 'Error general'});
            }else if(user){
                res.send({message: 'BIENVENIDO A SU CUENTA', user:user});
            }else{
                res.status(404).send({message: ' Usuario o contraseña incorrectos'})
            }
        });
    }else{
        res.status(404).send({message:'Ingrese usuario y contraseña'});
    }
}

//Guardar
function saveUser(req, res){
    var user = new User();
    var params = req.body;

    user.name=params.name;
    user.lastname=params.lastname;
    user.username=params.username;
    user.password=params.password;

    user.save((err, userSaved)=>{
        if(err){
            res.status(500).send({message: 'Error en el servidor'});
        }{
            if(userSaved){
                res.status(200).send({user:userSaved});
            }else{
                res.status(200).send({message: 'Error, usuario no guardado'});
            }
        }
    });
}

//listar
function getUsers(req,res){
    User.find({}).exec((err, users)=>{
        if(err){
            res.status(500).send({message: 'Error en el servidor'});
        }else if(users){
            res.status(200).send({users: users});
        }else{
            res.status(200).send({message: 'No hay registros que mostrar'})
        }
    });
}

//Buscar
function getUser(req,res){
    let userId = req.params.id;
    User.findById(userId).exec((err, user)=>{
        if(err){
            res.status(500).send({message:'Error general'});
        }else if(user){
            res.status(200).send({user: user});
        }else{
            res.status(200).send({message: 'Usuario no encontrado'});
        }
    });
}

module.exports = {
    saveUser,
    getUsers,
    getUser,
    login
}