'use strict'

//Importancion del modelo contacto
var Animal = require('../models/animal.model');
function saveAnimal(req, res){
    //Instancia del contacto
    var animal = new Animal();
    //Capturo los datos
    var params = req.body;
    //Validacion de que me lleguen los datos
    if(params.name && params.food){
        Animal.findOne({name: params.name}, (err, nameExist)=>{
            if(err){
                res.status(500).send({message: 'Error general'});
            }else if(nameExist){
                res.status(200).send({message: 'Ya existe un animal con el mismo nombre'});
            }else{
                animal.name = params.name;
                animal.food = params.food;

                animlal.save((err, animalSaved)=>{
                    if(err){
                        res.status(500).send({message: 'Error general', err});
                    }else if(animalSaved){
                        res.status(200).send({animal: animalSaved});
                    }else{
                        res.status(404).send({message: 'Animal no guardado'});
                    }
                });
            }
        });
    }else{
        res.status(200).send({message: 'Ingresa todos los campos requeridos'});
    }
}

//listar
function getAnimals(req, res){
    Animal.find({}).exec((err, animals)=>{
        if(err){
            res.status(500).send({message: 'Error en el servidor'});
        }else if(animals){
            res.status(200).send({animals: animals});
        }else{
            res.status(200).send({message: 'No hay registros'});
        }
    });
}

//Buscar
function getAnimal(req, res){
    let animalId = req.params.id;
    Animal.findById(animalId, (err, animal)=>{
        if(err){
            res.status(500).send({message: 'Error general'});
        }else if(animal){
            res.status(200).send({animal: animal});
        }else{
            res.status(404).send({message: 'Sin dato que mostrar'});
        }
    });
}

module.exports = {
    saveAnimal,
    getAnimals,
    getAnimal
}