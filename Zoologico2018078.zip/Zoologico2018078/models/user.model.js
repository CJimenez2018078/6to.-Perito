'use strict'

var mongoose = require('mongoose');
var Schema = mongoose.Schema;

//Esquema
var userSchema = Schema({
    name: String,
    username: String,
    password: String,
    lastname: String,
    position: String,
    age: Number,
    phone: Number,
    animals:[{
        name: String,
        age: Number,
        food: String
    }]
});

//Exportacion
module.exports = mongoose.model('user', userSchema);