'use strict'

var express = require('express');
var userController = require('../controllers/user.controller');
var api = express.Router();
var mdAuth = require('../middlewares/authenticated');

//Usuario
//guardar
api.post('/saveUser', userController.saveUser);
//login
api.post('/loginU', userController.loginU);
//listar
api.get('/listUser', mdAuth.ensureAuth, userController.listUser);
//actualizar
api.put('/updateUser/:id', mdAuth.ensureAuth, userController.updateUser);
//eliminar
api.delete('/removeUser/:id', mdAuth.ensureAuth, userController.removeUser);
//busqueda por calificacion
api.post('/Qualification', mdAuth.ensureAuth, userController.Qualification);
//orden de a - z
api.post('/AaZ', mdAuth.ensureAuth, userController.AaZ);
//orden de z - a
api.post('/ZaA', mdAuth.ensureAuth, userController.ZaA);
//precio de mayor a menor
api.post('/MayoraMenor', mdAuth.ensureAuth, userController.MayoraMenor);
//precio de menor a mayor
api.post('/MenoraMayor', mdAuth.ensureAuth, userController.MenoraMayor);

module.exports = api;