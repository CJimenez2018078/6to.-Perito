'use strict'

var express = require('express');
var hotelController = require('../controllers/hotel.controller');
var api = express.Router();
var mdAuth = require('../middlewares/authenticated');

//Guardar administrador
api.post('/saveHotel', mdAuth.ensureAuthAdmin, hotelController.saveHotel);
api.post('/loginH', mdAuth.ensureAuthAdmin, hotelController.loginH);
api.get('/listHoteles', mdAuth.ensureAuthHotel, hotelController.listHoteles);
api.put('/updateHotel/:id', mdAuth.ensureAuthHotel, hotelController.updateHotel);
api.delete('/removeHotel/:id', mdAuth.ensureAuthHotel, hotelController.removeHotel);
api.get('/detHotel/:id', mdAuth.ensureAutohHotel, hotelController.detHotel);
module.exports = api;