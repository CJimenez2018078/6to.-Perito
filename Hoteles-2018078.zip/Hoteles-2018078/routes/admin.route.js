'use strict'

var express = require('express');
var adminController = require('../controllers/admin.controller');
var api = express.Router();
var mdAuth = require('../middlewares/authenticated');

//Guardar administrador
api.post('/saveAdmin', adminController.saveAdmin);
api.post('/login', adminController.login);

module.exports = api;