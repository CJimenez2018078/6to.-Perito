'use strict'

var Hotel = require('../models/hotel.model');
//Bcrypt encriptar contraseñas
var bcrypt = require('bcrypt-nodejs');
//jwt
var jwt = require('../services/jwt2');

function saveHotel(req, res){
    var hotel = new Hotel();
    var params = req.body;

    if( params.name &&
        params.email &&
        params.password &&
        params.country &&
        params.arrival &&
        params.exit &&
        params.qualification &&
        params.price){
            Hotel.findOne({$or:[{name: params.name}, {email: params.email}]}, (err, hotelFind)=>{
                if(err){
                    res.status(500).send({message: 'Error general, intentelo mas tarde'});
                }else if(hotelFind){
                    res.send({message: 'Nombre o correo ya utilizado'});
                }else{
                    hotel.name = params.name;
                    hotel.address = params.address;
                    hotel.email = params.email;
                    hotel.password = params.password;
                    hotel.country = params.country;
                    hotel.arrival = params.arrival;
                    hotel.exit = params.exit;
                    hotel.qualification = params.qualification;
                    hotel.price = params.price;
                    hotel.role = 'HOTEL';

                    bcrypt.hash(params.password, null, null, (err, passwordHash)=>{
                        if(err){
                            res.status(500).send({message: 'Error al encriptar contraseña'});
                        }else if(passwordHash){
                            hotel.password = passwordHash;

                            hotel.save((err, hotelSaved)=>{
                                if(err){
                                    res.status(500).send({message: 'Error general al guardar usuario'});
                                }else if(hotelSaved){
                                    res.send({message: 'Hotel creado', hotel: hotelSaved});
                                }else{
                                    res.status(404).send({message: 'Hotel no guardado'});
                                }
                            });
                        }else{
                            res.status(418).send({message: 'Error inesperado'});
                        }
                    });
                }
            });
    }else{
        res.send({message: 'Ingresa todos los datos'});
    }
}

function loginH(req, res){
    var params = req.body;

    if(params.email){
        if(params.password){
            Hotel.findOne({email: params.email}, (err, check)=>{
                    if(err){
                        res.status(500).send({message: 'Error general'});
                    }else if(check){
                        bcrypt.compare(params.password, check.password, (err, passworOk)=>{
                            if(err){
                                res.status(500).send({message: 'Error al comparar'});
                            }else if(passworOk){
                                if(params.gettoken = true){
                                    res.send({token: jwt.createToken(check)});
                                }else{
                                    res.send({message: 'Bienvenido',hotel:check});
                                }
                            }else{
                                res.send({message: 'Contraseña incorrecta'});
                            }
                        });
                    }else{
                        res.send({message: 'Datos incorrectos'});
                    }
                });
        }else{
           res.send({message: 'Ingresa la contraseña'}); 
        }
    }else{
        res.send({message: 'Ingresa tu correo'});
    }
}

function updateHotel(req, res){
    var hotelId = req.params.id;
    var update = req.body;

    Hotel.findByIdAndUpdate(hotelId, update, {new: true},(err, hotelUpdated)=>{
        if(err){
            res.status(500).send({message:'Error general'});
        }else{
            if(hotelUpdated){
                res.status(200).send({message: 'Datos actualizados', hotel: hotelUpdated});
            }else{
                res.status(404).send({message: 'No se actualizó el dato'});
            }
        }
    });
}

function removeHotel(req, res){
    var hotelId = req.params.id;

    Hotel.findByIdAndRemove(hotelId, (err, hotelRemove)=>{
        if(err){
            res.status(500).send({message: 'Error general'});
        }else if(hotelRemove){
            res.send({message: 'Hotel eliminado', hotelRemove});
        }else{
            res.status(404).send({message: 'No se elimino el hotel de la BD'});
        }
    });
}

function listHoteles(req, res){
    Hotel.find({}, (err, hoteles)=>{
        if(err){
            res.status(418).send({message: 'Error general en la busqueda'});
        }else if (hoteles){
            res.send({hoteles});
        }else{
            res.status(418).send({message: 'Sin datos que mostrar'});
        }
    });
}

var PDF = require('pdfkit');

function detHotel(req, res){
    var pId = req.params.id;
    var pdf = new PDF();
    pdf.pipe(fs.createWriteStream('Hotel.pdf'));
        Hotel.findById(pId, (err, hotel)=>{
            if(err){
                res.status(500).send({message: 'Error general', err});
            }else if(hotel){
                pdf.text('Detalles del hotel seleccionado:');
                pdf.text(hotel);
                pdf.end();
                res.send({message: 'Proceso exitoso', hotel});
            }else{
                res.status(418).send({message: 'No se pudo generar el pdf'});
            }
        });       
}

module.exports = {
    saveHotel,
    loginH,
    listHoteles,
    updateHotel,
    removeHotel,
    detHotel
}