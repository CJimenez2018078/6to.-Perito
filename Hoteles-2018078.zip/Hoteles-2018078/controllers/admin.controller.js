'use strict'

//modelo a utilizar
var Admin = require('../models/admin.model');
//Encriptar contrasena
var bcrypt = require('bcrypt-nodejs');
//archivo services(jwt)
var jwt = require('../services/jwt');

function saveAdmin(req, res){
    var admin = new Admin();
    var params = req.body;

    if(params.username &&
        params.password){
            Admin.findOne({$or:[{username: params.username}, {email: params.email}, {password: params.password}]}, (err, adminFind)=>{
                if(err){
                    res.status(500).send({message: 'Error general', err});
                }else if(adminFind){
                    res.send({message: 'Nombre de usuario, correo o contrasenia ya registrados'});
                }else{
                    admin.name = params.name;
                    admin.username = params.username;
                    admin.email = params.email;
                    admin.password = params.password;
                    admin.role = 'ADMIN';

                    bcrypt.hash(params.password, null, null, (err, passwordHash)=>{
                        if(err){
                            res.status(500).send({message: 'Error al encriptar', err});
                        }else if(passwordHash){
                            admin.password = passwordHash;

                            admin.save((err, adminSaved)=>{
                                if(err){
                                    res.status(500).send({message: 'Error al Guardar', err});
                                }else if(adminSaved){
                                    res.send({message: 'Usuario administrador creado exitosamente', admin: adminSaved});
                                }else{
                                    res.status(418).send({message: 'El usuario no pudo ser guardado'});
                                }
                            });
                        }else{
                            res.status(404).send({message: 'Error inisperado'});
                        }
                    });
                }
            });
        }else{
            res.status(418).send({message: 'Ingrese un nombre de usuario y contrasenia'});
        }
}

function login(req, res){
    var params = req.body;

    if(params.username || params.email){
        if(params.password){
            Admin.findOne({$or:[{username: params.username}, {email: params.email}]}, (err, check)=>{
                if(err){
                    res.status(500).send({message: 'Error general', err});
                }else if(check){
                    bcrypt.compare(params.password, check.password, (err, passwordOk)=>{
                        if(err){
                            res.status(500).send({message: 'Error al comparar contrasenia'});
                        }else if(passwordOk){
                            if(params.gettoken = true){
                                res.send({token: jwt.createToken(check)});
                            }else{
                                res.send({message: 'Bienvenido a su cuenta', admin: check});
                            }
                        }else{
                            res.send({message: 'Contrasenia incorrecta'});
                        }
                    });
                }else{
                    res.send({message: 'Datos incorrectos'});
                }
            });
        }else{
            res.send({message: 'Ingrese su contrasenia'});
        }
    }else{
        res.send({message: 'Ingrese su contrasenia o nombre de usuario'});
    }
}

module.exports = {
    saveAdmin,
    login
}