'use strict'

//modelo a utilizar
var Admin = require('../models/user.model');
var Hotel = require('../models/hotel.model');
//Encriptar contrasena
var bcrypt = require('bcrypt-nodejs');
//archivo services(jwt)
var jwt = require('../services/jwt1');

function saveUser(req, res){
    var admin = new Admin();
    var params = req.body;

    if(params.username &&
        params.password){
            Admin.findOne({$or:[{username: params.username}, {email: params.email}, {password: params.password}]}, (err, adminFind)=>{
                if(err){
                    res.status(500).send({message: 'Error general', err});
                }else if(adminFind){
                    res.send({message: 'Nombre de usuario, correo o contrasenia ya registrados'});
                }else{
                    admin.name = params.name;
                    admin.username = params.username;
                    admin.email = params.email;
                    admin.password = params.password;
                    admin.role = 'USER';

                    bcrypt.hash(params.password, null, null, (err, passwordHash)=>{
                        if(err){
                            res.status(500).send({message: 'Error al encriptar', err});
                        }else if(passwordHash){
                            admin.password = passwordHash;

                            admin.save((err, adminSaved)=>{
                                if(err){
                                    res.status(500).send({message: 'Error al Guardar', err});
                                }else if(adminSaved){
                                    res.send({message: 'Usuario administrador creado exitosamente', admin: adminSaved});
                                }else{
                                    res.status(418).send({message: 'El usuario no pudo ser guardado'});
                                }
                            });
                        }else{
                            res.status(404).send({message: 'Error inisperado'});
                        }
                    });
                }
            });
        }else{
            res.status(418).send({message: 'Ingrese un nombre de usuario y contrasenia'});
        }
}

function loginU(req, res){
    var params = req.body;

    if(params.username || params.email){
        if(params.password){
            Admin.findOne({$or:[{username: params.username}, {email: params.email}]}, (err, check)=>{
                if(err){
                    res.status(500).send({message: 'Error general', err});
                }else if(check){
                    bcrypt.compare(params.password, check.password, (err, passwordOk)=>{
                        if(err){
                            res.status(500).send({message: 'Error al comparar contrasenia'});
                        }else if(passwordOk){
                            if(params.gettoken = true){
                                res.send({token: jwt.createToken(check)});
                            }else{
                                res.send({message: 'Bienvenido a su cuenta', user: check});
                            }
                        }else{
                            res.send({message: 'Contrasenia incorrecta'});
                        }
                    });
                }else{
                    res.send({message: 'Datos incorrectos'});
                }
            });
        }else{
            res.send({message: 'Ingrese su contrasenia'});
        }
    }else{
        res.send({message: 'Ingrese su contrasenia o nombre de usuario'});
    }
}

function updateUser(req, res){
    var userId = req.params.id;
    var update = req.body;

    Admin.findByIdAndUpdate(userId, update, {new: true},(err, userUpdated)=>{
        if(err){
            res.status(500).send({message:'Error general'});
        }else{
            if(userUpdated){
                res.status(200).send({message: 'Datos actualizados', user: userUpdated});
            }else{
                res.status(404).send({message: 'No se actualizó el dato'});
            }
        }
    });
}

function removeUser(req, res){
    var userId = req.params.id;

    Admin.findByIdAndRemove(userId, (err, userRemove)=>{
        if(err){
            res.status(500).send({message: 'Error general'});
        }else if(userRemove){
            res.send({message: 'Usuario eliminado', userRemove});
        }else{
            res.status(404).send({message: 'No se elimino el usuario de la BD'});
        }
    });
}

function listUser(req, res){
    Admin.find({}, (err, users)=>{
        if(err){
            res.status(418).send({message: 'Error general en la busqueda'});
        }else if (users){
            res.send({users});
        }else{
            res.status(418).send({message: 'Sin datos que mostrar'});
        }
    });
}
/*
function rangeDate(req, res){ 
    var moment = require('moment');
    var params = req.body;
    if(params.date){
        Hotel.find({
            
        });
    }else if( moment().isBetween( params.arrive, params.exit ) ){
        res.json( 'la fecha de hoy esta en el rango')
    }else{
        res.json( 'la fecha actual no esta en el rango')
    }
}*/

function Qualification(req, res){
    var params = req.body;

    Hotel.find({qualification: params.qualification}, (err, puntaje)=>{
        if(err){
            res.status(500).send({message: 'Error general'});
        }else if(puntaje){
            res.send({message: 'Hoteles con puntaje de: ', puntaje});
        }else{
            res.status(418).send({message:'No hay registro'});
        }
    });
}

function AaZ(req, res){
    var params = req.body;

    if(params.search = "ascendente"){
        Hotel.find((err, hoteles)=>{
            if(err){
                res.status(500).send({message: 'Error general'});
            }else if(hoteles){
                res.send({message: 'Hoteles ordenados de forma ascendente ', hoteles});
            }else{
                res.status(404).send({message: 'Error al mostrar'});
            }
        }).sort({name: 1});
    }else{
        res.status(418).send({message: 'Ingrese el parametro'}); 
    }
}

function ZaA(req, res){
    var params = req.body;

    if(params.search == "descendente"){
        Hotel.find((err, hotels)=>{
            if(err){
                res.status(500).send({message:'Error general 1'});
            }else if(hotels){
                res.send({message: 'Hoteles ordenados de forma descendente: ', hotels});
            }else{
                res.status(404).send({message: 'Error al mostrar 1'});
            }
        }).sort({name: -1});
    }else{
        res.status(418).send({message: 'Ingrese el parametro'});
    }
}

function MayoraMenor(req, res){
    var params = req.body;

    if(params.search = "ayor a menor"){
        Hotel.find((err, hoteles)=>{
            if(err){
                res.status(500).send({message: 'Error general'});
            }else if(hoteles){
                res.send({message: 'Hoteles ordenados por precio de mayor a menor: ', hoteles});
            }else{
                res.status(404).send({message: 'Error al mostrar'});
            }
        }).sort({price: 1});
    }else{
        res.status(418).send({message: 'Ingrese el parametro'}); 
    }
}

function MenoraMayor(req, res){
    var params = req.body;

    if(params.search == "menor a mayor"){
        Hotel.find((err, hotels)=>{
            if(err){
                res.status(500).send({message:'Error general 1'});
            }else if(hotels){
                res.send({message: 'Hoteles ordenados por precio menor a mayor:', hotels});
            }else{
                res.status(404).send({message: 'Error al mostrar 1'});
            }
        }).sort({name: -1});
    }else{
        res.status(418).send({message: 'Ingrese el parametro'});
    }
}

module.exports = {
    saveUser,
    loginU,
    updateUser,
    removeUser,
    listUser,
    Qualification,
    AaZ,
    ZaA,
    MayoraMenor,
    MenoraMayor
}