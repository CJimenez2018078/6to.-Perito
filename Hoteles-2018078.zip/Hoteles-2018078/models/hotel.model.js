'use strict'

var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var hotelSchema = Schema({
    name: String,
    address: String,
    email: String,
    password: String,
    country: String,
    arrival: String,
    exit: String,
    qualification: String,
    price: String,
    role: String
});

module.exports = mongoose.model('hotel', hotelSchema);