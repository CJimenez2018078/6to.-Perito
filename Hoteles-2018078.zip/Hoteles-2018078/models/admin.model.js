'use strict'

var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var adminSchema = Schema({
    name: String,
    username: String,
    email: String,
    password: String,
    role: String,
    hoteles: [{ type: Schema.Types.ObjectId, ref: 'hotel'}]
});

module.exports = mongoose.model('admin', adminSchema);