'use strict'

var jwt = require('jwt-simple');
var moment = require('moment');
var key = '12345';

exports.createToken = (admin)=>{
    var payload = {
        sub: admin._id,
        name: admin.name,
        username: admin.username,
        email: admin.email,
        password: admin.password,
        role: admin.role,
        iat: moment().unix(),
        exp: moment().add(3, "hours").unix()
    }
    return jwt.encode(payload, key);
}