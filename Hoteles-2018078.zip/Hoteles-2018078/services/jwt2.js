'use strict'

var jwt = require('jwt-simple');
var moment = require('moment');
var key = '12345';

exports.createToken = (hotel)=>{
    var payload = {
        sub: hotel._id,
        name: hotel.name,
        address: hotel.address,
        email: hotel.email,
        password: hotel.password,
        country: hotel.country,
        arrival: hotel.arrival,
        exit: hotel.exit,
        qualification: hotel.qualification,
        price: hotel.price,
        role: hotel.role,
        iat: moment().unix(),
        exp: moment().add(3, "hours").unix()
    }
    return jwt.encode(payload, key);
}