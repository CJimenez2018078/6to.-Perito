'use strict'

var User = require('../models/user.model');
var Tweet = require('../models/tweet.model');
var bcrypt = require('bcrypt-nodejs');
var jwt = require('../services/jwt');

function commands(req, res){
  var params = req.body;
  var access = JSON.stringify(params.command);
  var spaces = access.replace(/['"]+/g, "").split(" ");
  
//***********************************************Crear usuario************************************************//
  if(spaces[0].trim() == 'REGISTER'){
    let user = new User();

    if(spaces[1].trim() != null, spaces[2].trim() != null, spaces[3].trim() != null, spaces[4].trim() != null,
        spaces[5].trim() != null, spaces[6].trim() != null,spaces[7].trim() != null){
          User.findOne({$or:[{username: spaces[3].trim()}, {email: spaces[4].trim()}]}, (err, userFind)=>{
            if(err){
              res.status(500).send({message: 'Error general'});
            }else if(userFind){
              res.send({message: 'Nombre de usuario o correo ya utilizados'});
            }else{
              user.name = spaces[1].trim();
              user.lastName = spaces[2].trim();
              user.username = spaces[3].trim();
              user.email = spaces[4].trim();
              user.country = spaces[6].trim();
              user.age = spaces[7].trim();

            bcrypt.hash(spaces[5].trim(), null, null, (err, passwordHash)=>{
              if(err){
                res.status(500).send({message: 'Error al encriptar la contraseña'});
              }else if(passwordHash){
                user.password = passwordHash;
              }else{
                res.send({ message: "No se pudo encriptar la contraseña" });
              }
            });

            user.save((err, userSaved)=>{
              if(err){
                res.status(500).send({message: 'Error general al guardar datos del usuario'});
              }else if (userSaved){
                res.status(200).send({message: 'Usuario creado con éxito', user: userSaved});
              }else{
                res.status(404).send({message:'Usuario no guardado'});
              }
            });
          }
        });
      }else{
        res.status(418).send({message: 'Escriba todos los datos solicitados'});
      }
    }
//***********************************************Loguear usuario************************************************//
  if(spaces[0].trim() == 'LOGIN'){
    let pass = spaces[2].trim();

    if(spaces[1].trim() != null && spaces[2].trim() != null) {
      User.findOne({$or:[{username: spaces[1].trim()}, {email: spaces[1].trim()}]}, (err, userFind)=>{
          if(err){
            res.status(500).send({message: 'Error general'});
          }else if(userFind){
            bcrypt.compare(pass, userFind.password, (err, passworOk)=>{
                if(err){
                  res.status(500).send({message: 'Ingrese su nombre de usuario y correo con su contraseña'});
                }else if(passworOk){
                  if(params.gettoken = true){
                    res.send({token: jwt.createToken(userFind)});
                  }else{
                    res.send({message: 'Error en la solicitud'});
                  }
                }else{
                  res.status(500).send({message: 'Contraseña incorrecta'});
                }
              });
          }else{
            res.status(404).send({message: 'Error al comparar contraseña'});
          }
        });
    }else{
      res.send({ message:'Nombre de usuario o correo incorrectos'});
    }
  }
//***********************************************Agregar un Tweet************************************************//
  if (spaces[0].trim() == 'ADD_TWEET') {
    let idU = req.params.id;
    let tweet = new Tweet();

    if(idU != req.user.sub){
      res.status(500).send({message: 'Escribe el id del usuario en la ruta'});
    }else{
      if(spaces[1].trim().length != 0 && spaces[1].trim().length <= 114){
        tweet.tweets = spaces[1].trim();

        tweet.save((err, tweetSaved)=>{
          if(err){
            res.status(500).send({message: 'Error general al realizar la peticion'});
          }else if(tweetSaved){
            User.findByIdAndUpdate(idU, {$push:{ tweet: tweetSaved}}, {new: true}, (err, tweetUpdateUser)=>{
                if(err){
                  res.status(500).send({message: 'Error general al realizar la peticion de usuario'});
                }else if(tweetUpdateUser){
                  res.send({message: 'Tweet posteado correctamente', tweetUpdateUser});
                }else{
                  res.send({message: 'No se puedo guardar el tweet'});
                }
              }
            ).populate('tweet');
          }else{
            res.status(418).send({message: 'No se ha podido crear el tweet'});
          }
        });
      }else{
        res.send({message: 'No has escrito nada o sobrepasaste el limite de caracteres(144)'});
      }
    }
  }
//***********************************************Eliminar un Tweet************************************************//
  if(spaces[0].trim() == 'DELETE_TWEET'){
    var idU = req.params.id;
    var idT = spaces[1].trim();

    if(idU != req.user.sub){
      res.status(500).send({message: 'Escribe el id del usuario en la ruta'});
    }else{
      if(idT != null){
        Tweet.findByIdAndDelete(idT, (err, removeTweet)=>{
          if(err){
            res.status(500).send({message: 'Error general al realizar la peticion'});
          }else if(removeTweet){
            User.findByIdAndUpdate(idU, {$pull: {tweet: idT}}, {new: true}, (err, removeTweetUser)=>{
                if(err){
                  res.status(500).send({message: 'Error general al realizar la solicitud'});
                }else if(removeTweetUser){
                  res.send({message: 'Tweet eliminado con éxito', removeTweetUser});
                }else{
                  res.status(418).send({message: 'No se ha podido eliminar el tweet'});
                }
              }
            ).populate('tweet');
          }else{
            res.status(404).send({message: 'NO se encontro alguna coincidencia'});
          }
        });
      }else{
        res.status(418).send({ message: 'Ingrese el id del tweet a eliminar'});
      }
    }
  }
//***********************************************Editar un Tweet************************************************//
  if(spaces[0].trim() == 'EDIT_TWEET'){
    let idU = req.params.id;
    let idT = spaces[1].trim();
    let updated = spaces[2].trim();

    if(idU != req.user.sub){
      res.status(500).send({message: 'Escribe el id del usuario en la ruta'});
    }else{
      if(updated == null || idT == null){
        res.status(500).send({message: 'Error general al realizar la peticion'});
      }else{
        Tweet.findByIdAndUpdate(idT, {tweets: updated}, {new: true}, (err, updateTweet) => {
          if(err){
            res.status(500).send({message: 'Error general al realizar la solicitud'});
          }else if(updateTweet){
            User.findById(idU, {username: 1, tweet: 1, _id: 0}, (err, findId) => {
              if(err){
                res.send({message:'Error al buscar'});
              }else if(findId){
                res.send({message: 'Tweet actualizado', tweets:findId});
              }else{
                res.status(418).send({message: 'No se ha podido actualizar el tweet'});
              }
            }).populate('tweet');
          }else{
            res.status(404).send({message: 'NO se encontro alguna coincidencia'});
          }
        });
      }
    }
  }
//***********************************************Ver los Tweets************************************************//
  if(spaces[0].trim() == 'VIEW_TWEETS'){
    let idU = req.params.id;

    if(idU != req.user.sub){
      res.status(500).send({message: 'Escribe el id del usuario en la ruta'});
    }else{
      if(spaces[1].trim() == null){
        res.status(500).send({message: 'Error general al realizar la peticion'});
      }else{
        User.findOne({username: spaces[1].trim()}, {username: 1, tweet: 1, _id: 0}, (err, findTweets)=>{
            if(err){
              res.status(500).send({message:'Error al buscar'});
            }else if(findTweets){
              res.send({ message:'Tweets hechos: ', tweets: findTweets });
            }else{
              res.status(418).send({message: 'No se ha podido mostrar los tweets'});
            }
          }).populate('tweet');
        }
      }
    }
//***********************************************Seguir usuarios************************************************//
  if(spaces[0].trim() == 'FOLLOW'){
    let idU = req.params.id;

    if(idU != req.user.sub){
      res.status(500).send({message: 'Escribe el id del usuario en la ruta'});
    }else{
      if(spaces[1].trim() == ""){
        res.status(500).send({message: 'Error general al realizar la peticion'});
      }else{
        User.findOne({username: spaces[1].trim()}, {name: 1, username: 1, tweet: 1, _id: 0}, (err, findUser)=>{
            if(err){
              res.status(500).send({message:'Error al buscar'});
            }else if(findUser){
              User.findOne({_id: idU, friends: {$elemMatch:{username: findUser.username}}}, (err, userFind)=>{
                  if(err){
                    res.status(500).send({message:'Error al buscar'});
                  }else if(userFind){
                    res.status(500).send({ message: 'Ya sigues a este usuario'});
                  }else{
                    User.findByIdAndUpdate(idU, {$push:{ friends: findUser}}, {new: true}, (err, userUpdate)=>{
                        if(err){
                          res.status(500).send({message: 'Error general al realizar la peticion'});
                        }else if(userUpdate){
                          res.send({message:'Seguimiento correcto', user: userUpdate});
                        }else{
                          res.status(418).send({message: 'No se ha podido seguir a este usuario '});
                        }
                      });
                    }
                  });
                }else{
                  res.status(418).send({message: 'Este usuario no existe'});
                }
              });
            }
          }
        }
//***********************************************Dejar de seguir usuarios************************************************//
  if(spaces[0].trim() == 'UNFOLLOW'){
    let idU = req.params.id;

    if(idU != req.user.sub){
      res.status(500).send({message: 'Escribe el id del usuario en la ruta'});
    }else{
      if(spaces[1].trim() == ""){
        res.status(500).send({message: 'Error general al realizar la peticion'});
      }else{
        User.findByIdAndUpdate(idU, {$pull:{ friends:{ username: spaces[1].trim()}}}, {new: true}, (err, updateUser)=>{
            if(err){
              res.status(500).send({message:'Error al buscar'});
            }else if(updateUser){
              res.send({message:'Ya no sigues a este usuario', user: updateUser});
            }else{
              res.send({ message: 'Usuario inexistente'});
            }
          });
        }
      }
    }
//***********************************************Perfil de usuario************************************************//
  if(spaces[0].trim() == 'PROFILE'){
    let idU = req.params.id;

    if(idU != req.user.sub){
      res.status(500).send({ message: 'Escribe el id del usuario en la ruta'});
    }else{
      if(spaces[1].trim() == ""){
        res.status(500).send({message: 'Error general al realizar la peticion'});
      }else{
        User.findOne({username: spaces[1].trim()}, (err, userFind)=>{
            if(err){
              res.status(500).send({message:'Error al buscar'});
            }else if(userFind){
              res.send({message:'Perfil de usuario',user: userFind });
            }else{
              res.send({ message: "No se pudo encontrar el usuario" });
            }
          });
        }
      }
    }
  }

module.exports = {
  commands,
};
