'use strict'

var express = require('express');
var userController = require('../controllers/user.controller');
var md_Auth = require('../middleware/authenticated');

var api = express.Router();

api.post('/request/:id?', md_Auth.ensureAuth, userController.commands);

module.exports = api;