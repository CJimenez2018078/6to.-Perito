'use estrict'

var mongoose = require('mongoose');
var port = 3500;
var app = require('./app');

mongoose.Promise = global.Promise

mongoose.connect('mongodb://localhost:27017/DBTwitter-2018078', {useNewUrlParser: true, useUnifiedTopology:true,useUnifiedTopology: true})
    .then(()=>{
        console.log('Conexion a base de datos correcta');
        app.listen(port, ()=>{
            console.log('Servidor de express corriendo en puerto', port);
            console.log('Al agregar un tweet o editarlo el contenido del mensaje no puede ir separado ejemplo: Hoy es un nuevo dia');
            console.log('Debe ir junto ejemplo: Hoyesunnuevodia');
        });
    }).catch(err =>{
        console.log('Error al conectarse a la BD', err);
});