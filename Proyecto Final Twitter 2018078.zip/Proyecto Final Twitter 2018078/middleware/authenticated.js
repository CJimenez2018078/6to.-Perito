'use strict'

var jwt = require('jwt-simple');
var moment = require('moment');
var key = '123456CJ';

exports.ensureAuth = (req, res, next)=>{
  var command = req.body;
  var params = JSON.stringify(command.command);
  var spaces = params.split(" ");
  if(spaces[0].replace('"', "").trim() == "LOGIN" || spaces[0].replace('"', "").trim() == "REGISTER"){
    next();
  }else{
    if(!req.headers.authorization){
      return res.status(403).send({menssage: 'Peticion sin autentificacion'});
    }else{
      var token = req.headers.authorization.replace(/['"']+/g, '');
      try{
        var payload = jwt.decode(token, key);

        if(payload.exp <= moment().unix()){
          return res.status(401).send({menssage: 'Token expirado'});
        }
      }catch(ex){
        return res.status(404).send({menssage: 'El token no es valido'});
      }
      req.user = payload;
      next();
    }
  }
}