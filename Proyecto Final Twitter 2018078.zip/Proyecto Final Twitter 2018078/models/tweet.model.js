'use strict'

var mongoose = require('mongoose')
var Schema = mongoose.Schema;

var tweetSchema = new Schema({
  tweets: String,
});

module.exports = mongoose.model('tweet', tweetSchema);
