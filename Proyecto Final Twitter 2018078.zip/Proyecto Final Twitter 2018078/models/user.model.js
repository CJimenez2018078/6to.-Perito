var mongoose = require('mongoose');

var Schema = mongoose.Schema;

var userSchema = new Schema({
  name: String,
  lastName: String,
  username: String,
  email: String,
  password: String,
  country: String,
  age: Number,
  friends: [],
  tweet: [{ type: Schema.Types.ObjectId, ref: 'tweet' }],
});

module.exports = mongoose.model('user', userSchema);
