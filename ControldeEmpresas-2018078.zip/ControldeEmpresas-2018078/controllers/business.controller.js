'use strict'
//Exportacion del modelo
var Business = require('../models/business.model');
var Employee = require('../models/employee.model');
//jwt
var jwt = require('../services/jwt');
//Eliminar archivos, etc.(administracion de archivos en el servidor)
var fs = require('fs');
//Busqueda en rutas fisicas(manejo de rutas en el servidor)
var path = require('path');
//Encriptar contrasenias
var bcrypt = require('bcrypt-nodejs');
//Creacion de excel
var excel = require('mongo-xlsx');

//FUNCION DE REGISTRAR EMPRESA
function saveBusiness(req, res){
    var business = new Business();
    var params = req.body;

    if(params.companyNumber &&
        params.businessName &&
        params.phone &&
        params.president &&
        params.country){
            Business.findOne({$or:[{companyNumber: params.companyNumber},
                {businessName: params.businessName},
                {phone: params.phone},
                {taxResidence: params.taxResidence},
                {generalMail: params.generalMail},
                {password: params.password}]}, (err, businessFind)=>{
                    if(err){
                        res.status(500).send({message: 'Error general'});
                    }else if(businessFind){
                        res.send({message: 'Numero de empresa, nombre de empresa, telefono, direccion o correo de la empresa ya registrados'});
                    }else{
                        business.companyNumber = params.companyNumber;
                        business.businessName = params.businessName;
                        business.taxResidence = params.taxResidence;
                        business.role = 'ADMIN';
                        business.phone = params.phone;
                        business.generalMail = params.generalMail;
                        business.password = params.password;
                        business.president = params.president;
                        business.presidentialMail = params.presidentialMail;
                        business.country = params.country;
                        business.employess = params.employess;
                        business.product = params.product;
                        business.cantProduct = params.cantProduct;

                        bcrypt.hash(params.password, null, null, (err, passwordHash)=>{
                            if(err){
                                res.status(500).send({message: 'Error al encriptar la contraseña'});
                            }else if(passwordHash){
                                business.password = passwordHash;

                                business.save((err, businessSaved)=>{
                                    if(err){
                                        res.status(500).send({message: 'Error general al guardar la empresa'});
                                    }else if(businessSaved){
                                        res.send({message: 'Empresa creada', businessSaved});
                                    }else{
                                        res.status(418).send({message: 'No se pudo crear la empresa'});
                                    }
                                });
                            }   
                        });
                    }
                });
        }else{
            res.status(418).send({message: 'Ingrese los campos minimos'});
        }
}

//Listar empresas registradas
function getBus(req, res){
    Business.find({}).exec((err, business)=>{
        if(err){
            res.send(500).send({message: 'Error en el servidor'});
        }else if(business){
            res.send({message: 'Empresas registradas:', business: business});
        }else{
            res.status(418).send({message: 'No hay datos que mostrar'});
        }
    });
}

//Actualizar datos de la empresa
function updateBusiness(req, res) {
    let businessId = req.params.id;
    let update = req.body;

    Business.findOne({ $or:[{companyNumber: update.companyNumber},
            {businessName: update.businessName},
            {phone: update.phone},
            {taxResidence: update.taxResidence}]}, (err, businessE)=>{
            if(err){
                res.status(500).send({ message: 'Error general' });
            }else if(businessE){
                res.send({ message: 'Numero de empresa, nombre de empresa, telefono o direccion ya registrados'});
            }else{

                Business.findByIdAndUpdate(businessId, update, { new: true }, (err, businessUpdated)=>{
                    if(err){
                        res.status(500).send({ message: 'Error de actualizacion' });
                    }else if(!businessUpdated){
                        res.status(404).send({ message: 'No se ha podido actualizar los datos de la empresa' });
                    }else{
                        res.send({ business: businessUpdated });
                    }
                });
            }
        });
}

//Eliminar la empresa
function removeBusiness(req, res){
    var businessId = req.params.id;

    Business.findByIdAndRemove(businessId, (err, remoBusiness)=>{
        if(err){
            res.status(500).send({message: 'Error general'});
        }else if(remoBusiness){
            res.send({message: 'Empresa eliminada correctamente:', business: remoBusiness});
        }else{
            res.status(418).send({message: 'La empresa no pudo ser eliminada'});
        }
    });
}

//Agregar empleado a la empresa
function addEmployee(req, res) {
    let busId = req.params.id;
    let paramsE = req.body;
    let employee = new Employee();

    Business.findById()

    if(paramsE.name && paramsE.stall && paramsE.department && paramsE.username && paramsE.email && paramsE.password){
            Employee.findOne({$or:[{username: paramsE.username},
                {email: paramsE.email}, {password: paramsE.password}]}, busId, (err, employeeFind)=>{
                    if(err){
                        res.status(500).send({message: 'Error general',err});
                    }else if(employeeFind){
                        res.send({message:'Usuario, email o contraseña ya existen'});
                    }else{
                        employee.name = paramsE.name;
                        employee.lastName = paramsE.lastName;
                        employee.birthDate = paramsE.birthDate;
                        employee.birthPlace = paramsE.birthPlace;
                        employee.dpi = paramsE.dpi;
                        employee.sex = paramsE.sex;
                        employee.maritalStatus = paramsE.maritalStatus;
                        employee.stall = paramsE.stall;
                        employee.department = paramsE.department;
                        employee.username = paramsE.username;
                        employee.email = paramsE.email;
                        employee.password = paramsE.password;
                        employee.phone = paramsE.phone;

                        bcrypt.hash(paramsE.password, null, null, (err, passwordHash)=>{
                            if(err){
                                res.status(500).send({message: 'Error al encriptar la contraseña'});
                            }else if(passwordHash){
                                employee.password = passwordHash;

                                Business.findByIdAndUpdate(busId, { $push: { employees: employee } }, { new: true }, (err, busUpdate) =>{
                                    if (err) {
                                        res.status(500).send({ message: 'Error general' });
                                    } else if (busUpdate) {
                                        res.send({ business: busUpdate});
                                    } else {
                                        res.status(404).send({ message: 'Empresa no actualizado' });
                                    }
                                });

                            }else{
                                res.status(418).send({message: 'Error inesperado'});
                            }
                        });
                    }
                });
        }else{
            res.status(418).send({message: 'Ingrese los datos requeridos'});
        }
}

//Cantidad de empleados laborando en la empresa
function countEmployee(req, res) {
    var businessId = req.params.id;
    Business.findById(businessId, (err, employeeOk) => {
        if (err) return res.status(500).send({ message: 'Error General' });
        if (!employeeOk) return res.status(418).send({ message: 'No se pudo mostrar la cantidad' });
        console.log(employeeOk.length)
        return res.send({ Cantidad_de_empleados_registrados_en_la_empresa: employeeOk.employees.length })
    });
}

//Busqueda por coincidencia de empresas
function searchBusiness(req, res) {
    var params = req.body;

    if(params.search){
        Business.find({
            $or: [
                { businessName: { $regex: "^" + params.search, $options: 'i' } }, 
            { taxResidence: { $regex: "^" + params.search, $options: 'i' } },
            { generalMail: { $regex: "^" + params.search, $options: 'i' } },
            { country: { $regex: "^" + params.search, $options: 'i' } }
            ]
        },(err, searchBus)=>{
            if(err){
                res.status(500).send({message: 'Error general', err});
            }else if(searchBus){
                res.send({message: searchBus});
            }else{
                res.status(418).send({message: 'No se pudo realizar la busqueda'});
            }
        });
    }
}

//Login
function login(req, res){
    var params = req.body;

    if(params.generalMail || params.password){
        if(params.password){
            Business.findOne({$or:[{generalMail: params.generalMail}, 
                {password: params.password}]}, (err, check)=>{
                    if(err){
                        res.status(500).send({message: 'Error general', err});
                    }else if(check){
                        bcrypt.compare(params.password, check.password, (err, passworOk)=>{
                            if(err){
                                res.status(500).send({message: 'Error al comparar'});
                            }else if(passworOk){
                                if(params.gettoken = true){
                                    res.send({token: jwt.createToken(check)});
                                }else{
                                    res.send({message: 'Inicio de sesion correcto',business:check});
                                }
                            }else{
                                res.send({message: 'Contraseña incorrecta'});
                            }
                        });
                    }else{
                        res.send({message: 'Datos incorrectos'});
                    }
                });
        }else{
           res.send({message: 'Ingresa tu contraseña'}); 
        }
    }else{
        res.send({message: 'Ingresa correo general de la empresa'});
    }
}

function excelP(req, res) {
    Business.find({}, (err, find) => {
        if (err) {
            res.status(500).send({ message: "Error general.", err });
        } else if (find) {
            var doc = excel.buildDynamicModel(find);

            excel.mongoData2Xlsx(find, doc, (err, saved) => {
                if (err) {
                    res.status(500).send({ message: "Error general." });
                } else if (saved) {
                    res.send({ message: "Exitoso" });
                } else {
                    res.send({ message: "Error." });
                }
            });
        } else {
            res.send({ message: "Ha ocurrido un Error." });
        }
    });
}

function excelE(req, res) {
    Employee.find({}, (err, find) => {
        if (err) {
            res.status(500).send({ message: "Error general.", err });
        } else if (find) {
            var doc = excel.buildDynamicModel(find);

            excel.mongoData2Xlsx(find, doc, (err, saved) => {
                if (err) {
                    res.status(500).send({ message: "Error general." });
                } else if (saved) {
                    res.send({ message: "Exitoso" });
                } else {
                    res.send({ message: "Error." });
                }
            });
        } else {
            res.send({ message: "Ha ocurrido un Error." });
        }
    });
}

function searchProBus(req, res) {
    var params = req.body;

    if(params.search){
        Business.find({
           
            product: { $regex: "^" + params.search, $options: 'i' } 
            
        },(err, searchBus)=>{
            if(err){
                res.status(500).send({message: 'Error general', err});
            }else if(searchBus){
                res.send({message: searchBus});
            }else{
                res.status(418).send({message: 'No se pudo realizar la busqueda'});
            }
        });
        
    }
}

function cant(req, res){
    var params = req.body;

    Business.find({cantProduct: params.cantProduct}, (err, puntaje)=>{
        if(err){
            res.status(500).send({message: 'Error general'});
        }else if(puntaje){
            res.send({message: 'Cantidad de productos: ', puntaje});
        }else{
            res.status(418).send({message:'No hay registro'});
        }
    });
}

module.exports = {
    saveBusiness,
    getBus,
    updateBusiness,
    removeBusiness,
    addEmployee,
    countEmployee,
    searchBusiness,
    login,
    excelP, 
    excelE,
    searchProBus,
    cant
}