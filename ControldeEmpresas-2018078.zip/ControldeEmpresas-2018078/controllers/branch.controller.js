'use strict'
//Exportacion del modelo
var Branch = require('../models/branch.model');
//jwt
var jwt = require('../services/jwt');
//Eliminar archivos, etc.(administracion de archivos en el servidor)
var fs = require('fs');
//Busqueda en rutas fisicas(manejo de rutas en el servidor)
var path = require('path');
//Encriptar contrasenias
var bcrypt = require('bcrypt-nodejs')

//Registrar sucursal
function saveBranch(req, res){
    var branch = new Branch();
    var params = req.body;

    if(params.branchName &&
        params.branchAddress){
            Branch.findOne({$or:[{branchName: params.branchName},
                {branchAddress: params.branchAddress}]}, (err, branchFind)=>{
                    if(err){
                        res.status(500).send({message: 'Error general'});
                    }else if(branchFind){
                        res.send({message: 'Nombre o direccion de sucursal ya registrados'});
                    }else{
                        branch.branchName = params.branchName;
                        branch.branchAddress = params.branchAddress;
                        branch.product = params.product;
                        branch.cantProduct = params.cantProduct;

                        branch.save((err, branchSaved)=>{
                            if(err){
                                res.status(500).send({message: 'Error general'});
                            }else if(branchSaved){
                                res.send({message: 'Sucursal creada', branchSaved});
                            }else{
                                res.status(418).send({message: 'No se pudo crear la sucursal'});
                            }
                        });
                    }   
                });
            
        }else{
            res.status(418).send({message: 'Ingrese los campos minimos'});
        }
}

//Listar sucursal
function getBranch(req, res){
    Branch.find({}).exec((err, branchOk)=>{
        if(err){
            res.send(500).send({message: 'Error en el servidor'});
        }else if(branchOk){
            res.send({message: 'Sucursales registradas:', branches: branchOk});
        }else{
            res.status(418).send({message: 'No hay datos que mostrar'});
        }
    });
}

//Actualizar datos de la empresa
function updateBranch(req, res) {
    let branchId = req.params.id;
    let params = req.body;

    Branch.findByIdAndUpdate(branchId, params, { new: true }, (err, branchUpdated)=>{
        if(err){
            res.status(500).send({ message: 'Error de actualizacion', err });
        }else if(!branchUpdated){
            res.status(404).send({ message: 'No se ha podido actualizar los datos de la sucursal' });
        }else{
            res.send({ branch: branchUpdated });
        }
    });
}

//Eliminar la empresa
function removeBranch(req, res){
    var branchId = req.params.id;

    Branch.findByIdAndRemove(branchId, (err, remoBranch)=>{
        if(err){
            res.status(500).send({message: 'Error general', err});
        }else if(remoBranch){
            res.send({message: 'Sucursal eliminada correctamente:', branch: remoBranch});
        }else{
            res.status(418).send({message: 'La sucursal no pudo ser eliminada'});
        }
    });
}

var PDF = require('pdfkit');

function productB(req, res){
    var pId = req.params.id;
    var pdf = new PDF();
    pdf.pipe(fs.createWriteStream('Productos.pdf'));
        Branch.findById(pId, (err, produ)=>{
            if(err){
                res.status(500).send({message: 'Error general', err});
            }else if(produ){
                pdf.text('Sucursal y sus respectivos productos');
                pdf.text(produ);
                pdf.end();
                res.send({message: 'Proceso exitoso', produ});
            }else{
                res.status(418).send({message: 'No se pudo generar el pdf'});
            }
        });       
}

function searchProBra(req, res) {
    var params = req.body;

    if(params.search){
        Branch.find({
           
            product: { $regex: "^" + params.search, $options: 'i' } 
            
        },(err, searchBus)=>{
            if(err){
                res.status(500).send({message: 'Error general', err});
            }else if(searchBus){
                res.send({message: searchBus});
            }else{
                res.status(418).send({message: 'No se pudo realizar la busqueda'});
            }
        });
    }
}

function cant1(req, res){
    var params = req.body;

    Branch.find({cantProduct: params.cantProduct}, (err, puntaje)=>{
        if(err){
            res.status(500).send({message: 'Error general'});
        }else if(puntaje){
            res.send({message: 'Cantidad de productos: ', puntaje});
        }else{
            res.status(418).send({message:'No hay registro'});
        }
    });
}

module.exports = {
    saveBranch,
    getBranch,
    updateBranch,
    removeBranch,
    productB,
    searchProBra,
    cant1
}