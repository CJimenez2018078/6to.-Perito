'use strict'

//Exportacion del modelo
var Employee = require('../models/employee.model');
var Business = require('../models/business.model');
//Bcrypt para encriptar contrasenias
var bcrypt = require('bcrypt-nodejs');

//Agregar empleado
function saveEmployee(req, res){
    var employee = new Employee();
    var params = req.body;

    if(params.name &&
        params.stall &&
        params.department &&
        params.username &&
        params.email &&
        params.password){
            Employee.findOne({$or:[{username: params.username},
                {email: params.email}, {password: params.password}]}, (err, employeeFind)=>{
                    if(err){
                        res.status(500).send({message: 'Error general'});
                    }else if(employeeFind){
                        res.send({message:'Usuario, email o contraseña ya existen'});
                    }else{
                        employee.name = params.name;
                        employee.lastName = params.lastName;
                        employee.birthDate = params.birthDate;
                        employee.birthPlace = params.birthPlace;
                        employee.dpi = params.dpi;
                        employee.sex = params.sex;
                        employee.maritalStatus = params.maritalStatus;
                        employee.stall = params.stall;
                        employee.department = params.department;
                        employee.username = params.username;
                        employee.email = params.email;
                        employee.password = params.password;
                        employee.phone = params.phone;

                        bcrypt.hash(params.password, null, null, (err, passwordHash)=>{
                            if(err){
                                res.status(500).send({message: 'Error al encriptar la contraseña'});
                            }else if(passwordHash){
                                employee.password = passwordHash;

                                employee.save((err, employeeSaved)=>{
                                    if(err){
                                        res.status(500).send({message: 'Error general'});
                                    }else if(employeeSaved){
                                        res.send({message: 'Empleado creado:', employee: employeeSaved});
                                    }else{
                                        res.status(418).send({message: 'Empleado no creado'});
                                    }
                                });
                            }else{
                                res.status(418).send({message: 'Error inesperado'});
                            }
                        });
                    }
                });
        }else{
            res.status(418).send({message: 'Ingrese los datos requeridos'});
        }
}

//Listar empresas registradas
function getEmployee(req, res){
    Employee.find({}).exec((err, employee)=>{
        if(err){
            res.send(500).send({message: 'Error en el servidor'});
        }else if(employee){
            res.send({message: 'Empleados registrados:', employee});
        }else{
            res.status(418).send({message: 'No hay datos que mostrar'});
        }
    });
}

//Actualizar datos de la empresa
function updateEmploye(req, res) {
    let employeeId = req.params.id;
    let update = req.body;

    Employee.findOne({ $or:[{name: update.name},
            {dpi: update.dpi},
            {username: update.username},
            {email: update.email}]}, (err, employeeE)=>{
            if(err){
                res.status(500).send({ message: 'Error general', err });
            }else if(employeeE){
                res.send({ message: 'nombre, dpi, username o email ya registrados'});
            }else{

                Employee.findByIdAndUpdate(employeeId, update, { new: true }, (err, employeeUpdated)=>{
                    if(err){
                        res.status(500).send({ message: 'Error de actualizacion', err});
                    }else if(!employeeUpdated){
                        res.status(404).send({ message: 'No se ha podido actualizar los datos de la empresa' });
                    }else{
                        res.send({ employee: employeeUpdated });
                    }
                });
            }
        });
}

//Eliminar la empresa
function removeEmployee(req, res){
    var employeeId = req.params.id;

    Employee.findByIdAndRemove(employeeId, (err, remoEmployee)=>{
        if(err){
            res.status(500).send({message: 'Error general'});
        }else if(remoEmployee){
            res.send({message: 'Empleado eliminado correctamente:', employee: remoEmployee});
        }else{
            res.status(418).send({message: 'El empleado no pudo ser eliminado'});
        }
    });
}


function searchEmployee(req, res) {
    var params = req.body;

    if(params.search){
        Employee.find({
            $or: [
                { name: { $regex: "^" + params.search, $options: 'i' } }, 
            { username: { $regex: "^" + params.search, $options: 'i' } },
            { email: { $regex: "^" + params.search, $options: 'i' } },
            { stall: { $regex: "^" + params.search, $options: 'i' } },
            { department: { $regex: "^" + params.search, $options: 'i' } }
            ]
        },
        (err, searchE)=>{
            if(err){
                res.status(500).send({message: 'Error general'});
            }else if(searchE){
                res.send({message: searchE});
            }else{
                res.status(418).send({message: 'No se pudo realizar la busqueda'});
            }
        });
    }
}

module.exports = {
    saveEmployee,
    getEmployee,
    updateEmploye,
    removeEmployee,
    searchEmployee
}