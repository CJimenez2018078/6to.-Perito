'use strict'
//Exportacion de librerias
var express = require('express');
var bodyParser = require('body-parser');
var app = express();
var businessRoutes = require('./routes/business.route');
var employeeRoutes = require('./routes/employee.route');
var branchRoutes = require('./routes/branch.route');

//Parseo de datos de js a json
app.use(bodyParser.urlencoded({extended:false}));
app.use(bodyParser.json());

//Configuracion de los cors
app.use((req, res, next) => {
	res.header('Access-Control-Allow-Origin', '*');
	res.header('Access-Control-Allow-Headers', 'Authorization, X-API-KEY, Origin, X-Requested-With, Content-Type, Accept, Access-Control-Allow-Request-Method');
	res.header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, DELETE');
	res.header('Allow', 'GET, POST, OPTIONS, PUT, DELETE');
	next();
});

//uso de las rutas de business
app.use(businessRoutes);
//uso de las rutas de employee
app.use(employeeRoutes);
//uso  de las rutas de sucursales
app.use(branchRoutes);

//Exportacion del modulo app
module.exports = app;