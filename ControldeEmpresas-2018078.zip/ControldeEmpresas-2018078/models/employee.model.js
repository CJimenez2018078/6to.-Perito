'use strict'

var mongoose =  require('mongoose');
var Schema = mongoose.Schema;

var employeeSchema = Schema({
    name: String,
    lastName: String,
    birthDate: String,
    birthPlace: String,
    dpi: Number,
    sex: String,
    maritalStatus: String,
    stall: String,
    department: String,
    username: String,
    email: String,
    password: String,
    phone: Number
});

module.exports = mongoose.model('employee', employeeSchema);