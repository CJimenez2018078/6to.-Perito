'use strict'

var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var branchSchema = Schema({
    branchName: String,
    branchAddress: String,
    product: String,
    cantProduct: Number
});

module.exports = mongoose.model('branch', branchSchema);