'use strict'

var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var businessSchema = Schema({
    companyNumber: Number,
    businessName: String,
    taxResidence: String,
    role: String,
    phone: Number,
    generalMail: String,
    password: String,
    president: String,
    presidentialMail: String,
    country: String,
    employees: [{ name: String,
        lastName: String,
        birthDate: String,
        birthPlace: String,
        dpi: Number,
        sex: String,
        maritalStatus: String,
        stall: String,
        department: String,
        username: String,
        email: String,
        password: String,
        phone: Number}],
    product: String,
    cantProduct: String
});

module.exports = mongoose.model('business', businessSchema);